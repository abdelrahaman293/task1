def Process_list(INPUT_LIST):
    no_duplicte = set()
    ul = []
    for item in INPUT_LIST:
        if item not in no_duplicte:
          ul.append(item)
          no_duplicte.add(item)
    
    ul.reverse()
    return ul
INPUT_LIST = [22,21,10,96,45,23,20,10]

Result = Process_list(INPUT_LIST)
print("New list:", Result)
